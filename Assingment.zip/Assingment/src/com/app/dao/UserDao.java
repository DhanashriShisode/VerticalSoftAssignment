package com.app.dao;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


import com.app.pojos.User;



public class UserDao implements AutoCloseable{
private Connection con;

public UserDao() {
	// TODO Auto-generated constructor stub
System.out.println("inside ctor of user dao");
}
public void open() throws Exception {
	System.out.println("inside open()");
	con = JdbcUtils.getConnection();
}
@Override
public void close() {
	try {
		if(con != null)
			con.close();
	}catch (Exception e) {
		// ...
	}
}



public List<User> getUsers() throws Exception {
	System.out.println("inside dao.getuser");
	List<User> list = new ArrayList<>();
	/*String sql = "SELECT id, name, email, conno1, password FROM User";
	try(PreparedStatement stmt = con.prepareStatement(sql)) {
		try(ResultSet rs = stmt.executeQuery()) {
			while(rs.next()) {
				User u = new User();
				u.setId(rs.getInt("id"));
				u.setCity(rs.getString("city"));
				u.setConno1(rs.getString("conno1"));
				u.setName(rs.getString("name"));
				u.setEmail(rs.getString("email"));
				u.setPassword(rs.getString("password"));
				System.out.println(u);
				list.add(u);*/
	
	 try {		System.out.println("inside dao.getuser");

		 Class.forName("com.mysql.jdbc.Driver").newInstance();
		 Connection  con = DriverManager.getConnection("jdbc:mysql://localhost:3306/AJayashri","root", "");

		 String query = "select * FROM Jayashri";
		 System.out.println("connected to the database");
		 Statement st = con.createStatement();
		 ResultSet rs = st.executeQuery(query);
			System.out.println("inside dao.getuser");
			
		 
		 while(rs.next()) {
			 System.out.println("inside while loop");
			System.out.println(rs.getString("name"));
			User u = new User();
			u.setCity(rs.getString("city"));
			u.setEmail(rs.getString("email"));

			u.setConno1(rs.getString("conno1"));
			u.setConno2(rs.getString("conno2"));
			u.setGender(rs.getString("gender"));
			u.setName(rs.getString("name"));
		    u.setLanguage(rs.getString("language"));
			list.add(u);
			
		 }
	 } 
		 catch(Exception e) {
		 
	 }
	return list;
	
}

public String registerUser(User u) {

	
	 try {		System.out.println("inside dao.getuser");

	 Class.forName("com.mysql.jdbc.Driver").newInstance();
	 Connection  con = DriverManager.getConnection("jdbc:mysql://localhost:3306/AJayashri","root", "");

	 String query = "insert into Jayashri(name,city,email,conno1,conno2,gender,language)values(?,?,?,?,?,?,?)";
	 System.out.println("connected to the database");
	 PreparedStatement st = con.prepareStatement(query);
	 st.setString(1, u.getName());
	 st.setString(2, u.getCity());
	 st.setString(3, u.getEmail());
	 st.setString(4, u.getConno1());
	 st.setString(5, u.getConno2());
	 st.setString(6,u.getGender());
	 st.setString(7, u.getLanguage());
	 System.out.println(u);
		System.out.println("inside dao.register");
		try {
			st.executeUpdate();
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	con.close();
	 return "Registration Successfull";
	
	 
	 }catch(Exception e) {
		 System.out.println(e);
	 
 }
			

	
	return "Registration Failed";
}

public void test()
{
    System.out.println("hello");

}


		public  String delete(String name){  
		     
		    try{  
		        System.out.println("hello");
		    	Class.forName("com.mysql.jdbc.Driver").newInstance();
		    	Connection  con = DriverManager.getConnection("jdbc:mysql://localhost:3306/AJayashri","root", "");
		        PreparedStatement ps=con.prepareStatement("delete from Jayashri where name=?");  
		        ps.setString(1, name); 
		         ps.executeUpdate();  
		    }catch(Exception e)
		    {
		    	System.out.println(e);
		    }  
		  
		    return "successfully delete";  
		}  
}




