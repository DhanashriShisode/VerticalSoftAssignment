package com.app.utils;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class JdbcUtils {
	public static final String DB_DRIVER;
	public static final String DB_URL;
	public static final String DB_USER;
	public static final String DB_PASSWORD;
	
	static {
		Properties props = new Properties();
		try(InputStream in = JdbcUtils.class.getResourceAsStream("/jdbc.properties")) {
			props.load(in);
		} catch (Exception e) {
			e.printStackTrace();
		}
		DB_DRIVER = props.getProperty("db.driver", "");
		DB_URL = props.getProperty("db.url", "");
		DB_USER = props.getProperty("db.user", "");
		DB_PASSWORD = props.getProperty("db.password", "");
		
		try {
			Class.forName(DB_DRIVER);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static Connection getConnection() throws SQLException {
		Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
		return con;
	}
}






