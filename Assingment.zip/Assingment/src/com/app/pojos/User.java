package com.app.pojos;

public class User {
private String name,email,city,conno1,conno2,gender,password,language;
public String getLanguage() {
	return language;
}
public void setLanguage(String language) {
	this.language = language;
}
private int id;
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
public String getConno1() {
	return conno1;
}
public void setConno1(String conno1) {
	this.conno1 = conno1;
}
public String getConno2() {
	return conno2;
}
public void setConno2(String conno2) {
	this.conno2 = conno2;
}
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
@Override
public String toString() {
	return "User [name=" + name + ", email=" + email + ", city=" + city + ", conno1=" + conno1 + ", conno2=" + conno2
			+ ", gender=" + gender + ", password=" + password + ", language=" + language + ", id=" + id + "]";
}


}




