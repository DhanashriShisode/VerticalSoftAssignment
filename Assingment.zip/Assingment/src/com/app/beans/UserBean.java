package com.app.beans;


import java.util.List;

import com.app.dao.UserDao;
import com.app.pojos.*;
public class UserBean {

	private java.util.List<User> list;

	public java.util.List<User> getList() {
		return list;
	}

	public void setList(java.util.List<User> list) {
		this.list = list;
	}
	
	public void getUserList(){
//		System.out.println("inside getUserlist");
	UserDao dao = new UserDao();
			try {
				//dao.open();
				list = dao.getUsers();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		
		System.out.println(list.size());
	
	}
	
}
