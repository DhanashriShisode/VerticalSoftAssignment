package com.app.beans;

import com.app.dao.UserDao;
import com.app.pojos.User;

public class UpdateUserBean {
	private String name,email,city,conno1,conno2,gender,password,language;
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	private int id;
	
	public UpdateUserBean() {
		// TODO Auto-generated constructor stub
	System.out.println("inside newuserbean");
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getConno1() {
		return conno1;
	}
	public void setConno1(String conno1) {
		this.conno1 = conno1;
	}
	public String getConno2() {
		return conno2;
	}
	public void setConno2(String conno2) {
		this.conno2 = conno2;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	
	public String update(){
		UserDao dao = new UserDao();
		User u = new User();
		u.setCity(city);
		u.setName(name);
		u.setConno1(conno1);
		u.setConno2(conno2);
		u.setEmail(email);
		u.setGender(gender);
		u.setPassword(password);
		u.setLanguage(language);
		return dao.update(u);
	}
	@Override
	public String toString() {
		return "NewUserBean [name=" + name + ", email=" + email + ", city=" + city + ", conno1=" + conno1 + ", conno2="
				+ conno2 + ", gender=" + gender + ", password=" + password + ", language=" + language + ", id=" + id
				+ "]";
	}
	
}


